local component = require("component")
local event = require("event")
local computer = require("computer")


local i = 1

while true do
  print("Please connect the Redstone I/O for Chunk " .. i .. ".")
  local eventType, address, other1, other2 = event.pull("component_added")
  print(eventType .. " " .. address .. " registered.", other1, other2)
  computer.beep()
  i = i + 1
end