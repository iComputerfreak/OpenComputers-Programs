local component = require("component")
local gpu = component.gpu

function start()
  gpu.bind("649c8c8d-3db4-402c-802a-196c353abae8")
end